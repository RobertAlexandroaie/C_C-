﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Collections;

namespace PL3
{
    //nume_prenume_1A_L16_AtributeObserver.zip
    class Program
    {
        static void Main(string[] args)
        {
            User ionut = new User();
            ionut.parola = "asdasdasdasd";
            ionut.email = "ionut.danila@asii.ro";

            //Validator v = new Validator();
            //if(!v.IsValid(ionut))
            //{
            //    foreach(string message in v.Messages) 
            //        Console.WriteLine(message);
            //}

            
        }
            
    }
}
